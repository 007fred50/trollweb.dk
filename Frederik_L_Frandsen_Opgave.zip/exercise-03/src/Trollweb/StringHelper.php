<?php

namespace Trollweb;

class StringHelper
{
    public function camelCase($string)
    {
    }

    public function snakeCase($string)
    {
    }

    public function urlSlug($string)
    {
    }
}
