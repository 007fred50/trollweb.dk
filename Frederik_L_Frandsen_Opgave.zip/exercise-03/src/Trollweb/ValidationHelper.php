<?php

namespace Trollweb;

class ValidationHelper
{
    public function url($url)
    {
    }

    public function email($email)
    {
    }

    public function ip($ip)
    {
    }

    public function validate($content, $rules)
    {
    }
}
