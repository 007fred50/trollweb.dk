Har lavet 1,2 og 4

3, 5 kan jeg ikke finde ud af !