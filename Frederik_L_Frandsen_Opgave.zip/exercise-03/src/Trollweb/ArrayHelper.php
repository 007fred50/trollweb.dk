<?php

namespace Trollweb;

class ArrayHelper
{
    public function flatten($array)
    {
    }

    public function get($array, $key)
    {
    }

    public function removeKey($array, $key)
    {
    }

    public function removeValue($array, $value)
    {
    }
}
