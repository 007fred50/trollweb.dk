# Exercise 05

## Social media integration

Make public/index.php only accessible after you sign in with any social media account.

### Requirements

* You can use any existing open-source package you need.

### Extra credit

* Use composer to include packages.
* Show logged in users name on the page.
* Implement a logout button.
